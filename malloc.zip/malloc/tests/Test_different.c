#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <sys/time.h>

void test_simple_malloc_free() {
    printf("Running test 1 to test a simple malloc and free\n");

    for (int i = 0; i < NUM_ITERATIONS; i++) {
        char *ptr1 = (char *)malloc(65565);
        free(ptr1);
        char *ptr2 = (char *)malloc(65588);
        free(ptr2);
        char *ptr3 = (char *)malloc(55679);
        free(ptr3);
    }
}

void test_exercise_malloc_free() {
    printf("2 - Running test 2 for Exercise malloc and free\n");

    for (int i = 0; i < NUM_ITERATIONS; i++) {
        char *ptr = (char *)malloc(65535);

        char *ptr_array[10020];

        for (int j = 0; j < 10020; j++) {
            ptr_array[j] = (char *)malloc(10020);
        }

        free(ptr);

        for (int j = 0; j < 10020; j++) {
            if (j % 2 == 0) {
                free(ptr_array[j]);
            }
        }

        ptr = (char *)malloc(65535);
        free(ptr);
    }
}


void test_coalesce() {
    printf("3 - Running test 3 for Test coalesce\n");

    for (int i = 0; i < NUM_ITERATIONS; i++) {
        int *ptr1 = (int *)malloc(1200);
        int *ptr2 = (int *)malloc(1200);
        int *ptr3 = (int *)malloc(1200);
        int *ptr4 = (int *)malloc(1200);
        int *ptr5 = (int *)malloc(1200);
        int *ptr6 = (int *)malloc(1200);
        free(ptr1);
        free(ptr2);
        free(ptr3);
        free(ptr4);
        free(ptr5);
        free(ptr6);

        int *ptr7 = (int *)malloc(2048);

        free(ptr7);
        int *ptr8 = (int *)malloc(3098);
        free(ptr8);
    }
}

void test_block_split_reuse() {
    printf("4 - Running test 4 for Block split and reuse\n");

    for (int i = 0; i < NUM_ITERATIONS; i++) {
        char *ptr1 = (char *)malloc(2048);
        free(ptr1);

        char *ptr2 = (char *)malloc(1056);
        free(ptr2);

        char *ptr3 = (char *)malloc(10088);
        free(ptr3);

        char *ptr4 = (char *)malloc(1068);
        free(ptr4);
    }
}

int main() {
    struct timeval start, end;
    double cpu_time_used;

    gettimeofday(&start, NULL);
    test_simple_malloc_free();
    gettimeofday(&end, NULL);
    cpu_time_used = (end.tv_sec - start.tv_sec) * 1000.0; // Convert to milliseconds
    cpu_time_used += (end.tv_usec - start.tv_usec) / 1000.0;
    printf("Test 1 took %f milliseconds to execute.\n\n", cpu_time_used);

    gettimeofday(&start, NULL);
    test_exercise_malloc_free();
    gettimeofday(&end, NULL);
    cpu_time_used = (end.tv_sec - start.tv_sec) * 1000.0; // Convert to milliseconds
    cpu_time_used += (end.tv_usec - start.tv_usec) / 1000.0;
    printf("Test 2 took %f milliseconds to execute.\n\n", cpu_time_used);

    gettimeofday(&start, NULL);
    test_coalesce();
    gettimeofday(&end, NULL);
    cpu_time_used = (end.tv_sec - start.tv_sec) * 1000.0; // Convert to milliseconds
    cpu_time_used += (end.tv_usec - start.tv_usec) / 1000.0;
    printf("Test 3 took %f milliseconds to execute.\n\n", cpu_time_used);

    gettimeofday(&start, NULL);
    test_block_split_reuse();
    gettimeofday(&end, NULL);
    cpu_time_used = (end.tv_sec - start.tv_sec) * 1000.0; // Convert to milliseconds
    cpu_time_used += (end.tv_usec - start.tv_usec) / 1000.0;
    printf("Test 4 took %f milliseconds to execute.\n\n", cpu_time_used);

    return 0;
}